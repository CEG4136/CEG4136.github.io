#define N 2048
#define CORES 16
