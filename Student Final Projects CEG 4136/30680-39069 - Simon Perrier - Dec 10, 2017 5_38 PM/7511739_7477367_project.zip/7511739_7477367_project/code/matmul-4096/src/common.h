#define N 4096
#define CORES 16
