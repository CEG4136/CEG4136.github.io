/*
  hello_world.c

  Copyright (C) 2012 Adapteva, Inc.
  Contributed by Yaniv Sapir <yaniv@adapteva.com>

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program, see the file COPYING.  If not, see
  <http://www.gnu.org/licenses/>.
*/

// This is the HOST side of the Hello World example.
// The program initializes the Epiphany system,
// randomly draws an eCore and then loads and launches
// the device program on that eCore. It then reads the
// shared external memory buffer for the core's output
// message.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include <e-hal.h>

#include "common.h"

float matrixA[N][N];
float matrixB[N][N];
float matrixC[N][N];

int sectionsX = N/4;
int sectionsY = N/4;

unsigned clr = 0;

typedef struct timeval timeval_t;
timeval_t timer[2];

int main(int argc, char *argv[])
{
	e_platform_t platform;
	e_epiphany_t dev;
	e_mem_t   mbuf;

	int done[CORES],all_done;

	e_set_loader_verbosity(H_D0);
	e_set_host_verbosity(H_D0);

	// initialize system, read platform params from
	// default HDF. Then, reset the platform and
	// get the actual system parameters.
	e_init(NULL);
	e_reset_system();
	e_get_platform_info(&platform);

	//init operand matrices
	int i, j;
	for(i=0;i<N;i++) {
		for(j=0;j<N;j++) {
			matrixA[i][j] = 1;
			matrixB[j][i] = 1; //transpose so that we can pass cols as rows
			matrixC[i][j] = 0;
		}
	}


	int x, y;
	int secX, secY;
	
	gettimeofday(&timer[0], NULL);	
	
	e_open(&dev, 0, 0, platform.rows, platform.cols); //open epiphany (4x4 workgroup)
	e_reset_group(&dev); //reset epiphany
	e_load_group("e_matmul_task.elf", &dev, 0, 0, platform.rows, platform.cols, E_FALSE); //load code


	for(secX=0;secX<sectionsX;secX++) { //loop through 4x4 sections
		printf("Completed section %d of %d\n", (secX*sectionsY), (sectionsX*sectionsY));
		for(secY=0;secY<sectionsY;secY++) {

			for(x=0;x<platform.cols;x++) {  //loop through each core in the 4x4 section
				for(y=0;y<platform.rows;y++) {
					e_write(&dev, y, x, 0x2000, &matrixA[(secY*4) + y], N*sizeof(float));
					e_write(&dev, y, x, 0x4000, &matrixB[(secX*4) + x], N*sizeof(float));
					e_write(&dev, y, x, 0x7000, &clr, sizeof(clr));
				}
			}

			e_start_group(&dev); //start workgroup

			while(1){
				all_done=0;
				for (i=0; i<platform.rows; i++){
					for (j=0; j<platform.cols;j++){
						e_read(&dev, i, j, 0x7000, &done[i*platform.cols+j], sizeof(unsigned int));
						all_done+=done[i*platform.cols+j];
					}
				}
				if(all_done==CORES){
					break;
				}
			}

			//copy results from 4x4 section into the result matrix
			for(x=0;x<platform.cols;x++) {
				for(y=0;y<platform.rows;y++) {
					e_read(&dev, y, x, 0x6000, &matrixC[(secX*4) + x][(secY*4) + y], sizeof(float));
				}
			}
		}
	}
	
	gettimeofday(&timer[1]);
	
	double tdiff = (timer[1].tv_sec - timer[0].tv_sec)*1000 + ((double) (timer[1].tv_usec - timer[0].tv_usec) / 1000.0);
	printf("Time taken: %f ms\n", tdiff);
	printf("C[0][0] is %f\n", matrixC[0][0]);
	printf("C[%d][%d] is %f\n", N-1, N-1, matrixC[N-1][N-1]);

	e_close(&dev);
	e_finalize();

	return 0;
}
