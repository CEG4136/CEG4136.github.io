#!/bin/bash

set -e


cd Debug

./matmul-big.elf

