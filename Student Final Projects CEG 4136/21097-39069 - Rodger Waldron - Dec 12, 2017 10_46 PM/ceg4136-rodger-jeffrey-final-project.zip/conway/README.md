# conway
Conway's game of Life on the epiphany core

Inspired and loosely based on the parallela_examples [game of life](https://github.com/parallella/parallella-examples/tree/master/game-of-life) project

## Project Sections

### File parsing
### Settings up Cores w/ buffers
### State status broadcasting of Cores
### Game Iteration Synchronization with host
