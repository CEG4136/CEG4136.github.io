struct CoreState_{
	uint8_t dim;
	uint8_t *cells;
};

typedef struct CoreState_ CoreState;
