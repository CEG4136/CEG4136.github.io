#include "game.h"
#include <sys/stat.h>
#include <unistd.h>

#define N_READY 'N'
#define READY 'R'

struct Board;
struct CoreState;

CoreState* lol(uint8_t x, uint8_t y, Board* world){
	int core_cell_num =0;
	uint8_t h;
	uint8_t i;
	CoreState *core_state = malloc(sizeof(CoreState));
	core_state->dim = (world->dim * world->dim)/16;
	core_state->cells = malloc(sizeof(char) * core_state->dim);
	for(h = 0; h < world->dim; h+=4) {
		for (i = 0; i < world->dim; i+=4) {
			core_state->cells[core_cell_num] = world->world[x+h][y+i];
			core_cell_num++;
		}
	}
	return core_state;
}

void printGeneration(CoreState **gen, uint8_t world_dim){
	uint8_t x,y,z,i,j,t,width = gen[0][0].dim;
	char *buff = malloc(sizeof(char) * world_dim * world_dim);
	i=0;
	for(y=0; y < 4; y++){
		for(z=0; z < width; z++){
			for(x=0; x < 4; x++){
				buff[i] = gen[x][y].cells[z];
				i++;
			}
		}
		for(j=0;j<(i/world_dim);j++){
			putchar('\n');
			for(t=0; t< world_dim;t++) putchar(buff[t+(j*world_dim)]);
		}
		i=0;
	}
	printf("\n");
	return;
}

void run_conway(Board* world, uint32_t generations){
	e_platform_t platform;
	e_epiphany_t dev;
	char done[16];
	int all_done;

	int i=0;
	int j=0;
	int p=0;
	e_init(NULL);
    e_reset_system(); //reset Epiphany
    e_get_platform_info(&platform);

    e_open(&dev, 0, 0, platform.rows, platform.cols); //open all cores

	e_load_group("./build/emain.elf", &dev, 0, 0, platform.rows, platform.cols, E_FALSE);

	/*
	First 8 bytes :  unit8 = n
	Second array of all states a core represents
	*/
	CoreState *core_state;
	for (i=0; i<platform.rows; i++){
		for (j=0; j<platform.cols; j++){
			core_state = lol(i,j,world);
			CoreState *core = malloc(sizeof(CoreState*));
			core->dim = core_state->dim;
			core->cells = malloc(sizeof(char) *core->dim );
			e_write(&dev, i, j, 0x4000, &core_state->dim, sizeof(uint8_t));
			e_write(&dev, i, j, 0x4001, core_state->cells, sizeof(char) *core_state->dim);
			//e_read(&dev, i, j, 0x4001, core->cells, sizeof(char) * core->dim);
			//printf("next row: %u,%u\n",i,j);
		}
	}

	e_start_group(&dev);
	uint32_t current_iteration = 0;
	sleep(1);
	while(current_iteration < generations){
		printf("Waiting for cores...");
		while(1){
			all_done=0;
			for (i=0; i<platform.rows; i++){
				for (j=0; j<platform.cols;j++){
					e_read(&dev, i, j, 0x4000, &done[i*platform.cols+j], sizeof(char));
					all_done+=done[i*platform.cols+j]==READY ? 1:0;
				}
			}
			if(all_done==16){
				break;
			}
		}
		printf(" - %u Gen done... - Printing", current_iteration);
		CoreState **iteration_state = malloc(sizeof(CoreState **) * 4);
		for(i=0; i < 4 ; i++){
			iteration_state[i] = malloc(sizeof(CoreState *) * 4);
		}

		for (i=0; i<platform.rows; i++){
			for (j=0; j<platform.cols;j++){
				CoreState *core = malloc(sizeof(CoreState*));
				core->dim = (world->dim*world->dim)/16;
				core->cells = malloc(sizeof(char*) *core->dim );
				e_read(&dev, i, j, 0x4001, core->cells, sizeof(char*) * core->dim);
				iteration_state[i][j] = *core;
			}
		}
		if(current_iteration < generations){
		// Set cores to process next generations
			char go = N_READY;
			for (i=0; i<platform.rows; i++){
				for (j=0; j<platform.cols;j++){
					e_write(&dev, i, j, 0x4000, &go, sizeof(char));
				}
			}
		}
		printGeneration(iteration_state, world->dim);
		current_iteration++;
	}
	printf("End of Simulation\n" );
	return ;
}


/*

*/
