-This folder includes the program we fuzzed (Strings) and afl.

-This folder includes the graphs of the executions/sec for two fuzzers.

-The script and the fuzzer_stats were left on the machines, which we don't have access anymore.

-The script is well explained in the report.

-The approximate results are shown in the powerpoint presentation.