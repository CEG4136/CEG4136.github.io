READ ME 
To compile and test code insert your IP and twitter Keys
Then compile the code using "python3 psetup.py build_ext �-inplace"
Then run the code by importing cySent to python and running cySent.startwebapp()