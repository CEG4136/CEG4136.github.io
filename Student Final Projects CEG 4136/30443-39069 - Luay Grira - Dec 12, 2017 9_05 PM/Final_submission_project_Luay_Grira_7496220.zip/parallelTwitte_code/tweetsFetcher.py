#######################################
# Project name: Twitter sentiment     #
# Author: Luay Grira, Nicholas Gagnon #
# email: lgrir025@uottawa.ca          #
#######################################
import re
import tweepy
from tweepy import OAuthHandler
import datetime

#from flask import Flask
#app = Flask(__name__)

class TweetsFetcher(object):
    '''
    Generic Twitter Class for sentiment analysis.
    '''
    def __init__(self):
        '''
        Class constructor or initialization method.
        '''
        # keys and tokens from the Twitter Dev Console
        # nd tokens from the Twitter Dev Console

        consumer_key = 'XXXXXXXXXXXXXXXX'
        consumer_secret = 'XXXXXXXXXXXXXXXX'
        access_token = 'XXXXXXXXXXXXXXXX'
        access_token_secret = 'XXXXXXXXXXXXXXXX'



        try:
            # create OAuthHandler object
            self.auth = OAuthHandler(consumer_key, consumer_secret)
            # set access token and secret
            self.auth.set_access_token(access_token, access_token_secret)
            # create tweepy API object to fetch tweets
            self.api = tweepy.API(self.auth)
        except:
            print("Error: Authentication Failed")

    def search_tweets_group(self, keyWord, date, count=100,tweetId = None):
        '''
        Function to get a number (=count) of tweets based on the date
        they got created at, keyword and tweetId(optional)
        '''
        try:
            if tweetId == None:
                fetched_tweets = self.api.search(q = keyWord, count = 100, until = date)
            else:
                # call twitter api to fetch tweets
                fetched_tweets = self.api.search(q = keyWord, count = 100, until = date, max_id = tweetId)
            return fetched_tweets

        except tweepy.TweepError as e:
            # print error (if any)
            print("Error : " + str(e))


    def get_tweets(self, query, count, date):
        '''
        Main function to fetch all tweets and retrun them.
        '''
        # empty list to store parsed tweets
        tweets = []

        try:
            # Initial call to the twitter api to fetch the first group of tweets
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            fetched_tweets = self.search_tweets_group(keyWord=query, count=count, date=date)#,max_id=928772377026195456)#, max_id= 928772774369353728)
            lastID = None
            while True:
                # parsing tweets one by one
                for tweet in fetched_tweets:
                    # saving text of tweet
                    tweetText = tweet.text
                    tweetId   = tweet.id

                    if tweet.retweet_count > 0:
                        # if tweet has retweets, ensure that it is appended only once
                        if tweetText not in tweets:
                            tweets.append(tweetText)
                    else:
                        tweets.append(tweetText)
                    if(len(tweets) == count):
                        print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                        print(len(tweets))
                        break;
                if len(tweets) < count:
                    Id= tweetId - 1
                    fetched_tweets = self.search_tweets_group(query, date, count, Id)
                    print(Id)
                else:
                    break
            # return parsed tweets
            return tweets
        except tweepy.TweepError as e:
            # print error (if any)
            print("Error : " + str(e))
