#######################################
# Project name: Twitter sentiment     #
# Author: Luay Grira, Nicholas Gagnon #
# email: lgrir025@uottawa.ca          #
#######################################

import re
from textblob import TextBlob

def clean_tweet(tweet):
        '''
        Utility function to clean tweet text by removing links, special characters
        using simple regex statements.
        '''
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())

def get_tweet_sentiment(tweet):
        '''
        Utility function to classify sentiment of passed tweet
        using textblob's sentiment method
        '''
        # create TextBlob object of tweet text
        analysis = TextBlob(clean_tweet(tweet))
        # set sentiment
        if analysis.sentiment.polarity > 0:
            return 'positive'
        elif analysis.sentiment.polarity == 0:
            return 'neutral'
        else:
            return 'negative'
def anlyse_tweets(tweets):
        '''
        Main funtion for the twitter analuser module
        It loops of all the tweets and get their sentiments
        '''
        #Create an empty sentiments array
        sentiments = []

        for tweet in tweets:
            #append the result of the tweet's text sentiment
            sentiments.append(get_tweet_sentiment(tweet))
        #return the sentiment array
        return sentiments
