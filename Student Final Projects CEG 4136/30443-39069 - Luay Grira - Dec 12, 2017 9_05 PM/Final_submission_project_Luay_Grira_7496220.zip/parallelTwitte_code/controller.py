#######################################
# Project name: Twitter sentiment     #
# Author: Luay Grira, Nicholas Gagnon #
# email: lgrir025@uottawa.ca          #
#######################################
import datetime
import random
import sys
import tweetsFetcher
from   tweetsAnalyser import anlyse_tweets
from flask import Flask, request, g, render_template, jsonify, json, abort, send_file, session, redirect, url_for

from flask import Flask
app = Flask(__name__)

@app.route("/task", methods=['POST'])
def process_task():
    jsonObject     = request.get_json()
    startDate      =  jsonObject['startDate']
    numberOfTweets =  int(jsonObject['numberOfTweets'])
    keyword        =  jsonObject['keyWord']
    fetcher        = tweetsFetcher.TweetsFetcher()
    tweets         = fetcher.get_tweets(keyword, numberOfTweets, startDate)
    sentiments     = anlyse_tweets(tweets)
    sentimentResult = {'positive':sum(sentiment == 'positive' for sentiment in sentiments),
                       'negative':sum(sentiment == 'negative' for sentiment in sentiments),
                       'total':len(tweets)}
    return jsonify(sentimentResult)
