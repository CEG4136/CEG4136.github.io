#######################################
# Project name: Twitter sentiment     #
# Author: Luay Grira, Nicholas Gagnon #
# email: lgrir025@uottawa.ca          #
#######################################
import requests
import pickle
import threading
import datetime
import os
import random
import sys
from optparse import OptionParser
from flask import Flask, request, g, render_template, jsonify, json, abort, send_file, session, redirect, url_for
sys.path.append(os.path.dirname(__file__))
app = Flask(__name__, template_folder='views')

@app.route('/get_sentiment', methods=['GET'])
def assignTask():
    print('Starting the twitter sentiment program:')

    #The next few lines are used for testing, to able to accept user inputs
    #parser = OptionParser()
    #parser.add_option("-t", "--total-number-tweets", dest="totalNeededTweets", default="", help="Number of tweets needed")
    #parser.add_option("-k", "--keyWord", dest="keyWord", default="", help="The keyWord that will be used for the lookup")
    #(options, args) = parser.parse_args()
    #totalNeededTweets = int(options.totalNeededTweets)
    #SkeyWord = options.keyWord
    totalNeededTweets =  int(request.args.get('numberOfTweets'))
    keyWord  = request.args.get('keyword')
    print(totalNeededTweets)
    print(keyWord)
    filehandler = open('VMIpAddresses.obj', 'rb')
    VMIpAddresses = pickle.load(filehandler)
    #VMIpAddresses = ['127.0.0.1:5000', "192.168.56.101:5000"]
    #VMIpAddresses = ['138.197.153.217:5000']
    sseThreads = []
    results = []
    startDate  = datetime.datetime.now()
    print(startDate.strftime('%H-%M-%S'))
    tweetsPerVM =  totalNeededTweets/len(VMIpAddresses)
    for ipAddress in VMIpAddresses:
        thread = threading.Thread(target = sendTaskToVM, args=(startDate, tweetsPerVM, ipAddress, keyWord, results))
        sseThreads.append(thread)
        thread.start()
        startDate = startDate - datetime.timedelta(days=1)
    for thread in sseThreads:
        thread.join()
    print (results)
    positive = 0
    negative = 0
    for result in results:
        positive = positive + result['positive']
        negative = negative + result['negative']
    endDate  = datetime.datetime.now()
    print(endDate.strftime('%H-%M-%S'))
    return jsonify({'positive': positive , 'negative': negative})
def sendTaskToVM(startDate, count, ipAddress, keyWord, results):
    url = "http://" + ipAddress + ":5000/task"
    result = requests.post(url, json = {'startDate': startDate.strftime('%Y-%m-%d'), 'numberOfTweets': count, 'keyWord': keyWord})
    results.append(result.json())

@app.route('/')
def show_dashboard():
    return render_template('shell.html')

#----------------------------------------
if __name__ == "__main__":
    assignTask()
