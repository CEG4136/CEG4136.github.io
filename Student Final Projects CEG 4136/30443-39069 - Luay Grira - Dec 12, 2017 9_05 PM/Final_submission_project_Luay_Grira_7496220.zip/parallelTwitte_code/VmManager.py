#######################################
# Project name: Twitter sentiment     #
# Author: Luay Grira, Nicholas Gagnon #
# email: lgrir025@uottawa.ca          #
#######################################

import requests
import paramiko
import pickle
from paramiko import SSHClient
from scp import SCPClient


def setUpDroplets():
    scripts = ["tweetsFetcher.py", "tweetsAnalyser.py", "controller.py", "bootstrap.wsgi", "999-flask.conf"]
    #The below array has the IP addresses hard-coded, You need to change it to your VMs IP addresses
    dropletIpAddresses = ['138.197.153.217','138.197.141.129', '138.197.144.42']
    #TO use when no IP addresses is provided
    '''
    for index in range(1,10):
        dropletInfo = createDroplet(index)
        dropletIp = getDropletIP(dropletInfo)
        dropletIpAddresses.append(dropletIp)
    '''
    for ipAddress in dropletIpAddresses:
        dropletSession = connectToDroplet(ipAddress)
        installDependencies(dropletSession)
        uploadScripts(scripts, dropletSession)
        runFlask(dropletSession)
        closeDropletSession(dropletSession)
    saveVMIpAddresses(dropletIpAddresses)

#TO use when no IP addresses is provided
'''
def createDroplet(vmnumber):
    bodyrequest = ( "region": "tor1", "size": "1gb", "image": "debian-9-x64", "ssh_Keys": , "backups": false, "ipv6": false, "user_data": null, "private_networking": null, "volumes": null, "tags":[web])
    bodyrequest.name = "tweetscraper" + vmnumber
    bodyresponse = requests.post("https://api.digitalocean.com/v2/droplets", data = bodyrequest)
    return bodyresponse

def getDropletIP(dropletInfo):
    dropletId = dropletInfo.droplet.id
    requestURL = "https://api.digitalocean.com/v2/droplets/" + dropletId
    response = requests.get(requestURL)
    return response.droplet.networks.v4.ip_address

#Missing ssh key File
'''
def connectToDroplet(IpAddress):
    key = paramiko.RSAKey.from_private_key_file("../tweets_ceg4136")
    session = paramiko.SSHClient()
    session.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    print ("connecting to" + IpAddress)
    session.connect( hostname = IpAddress, username = "root", pkey = key )
    print ("connected to " + IpAddress)
    return session

def installDependencies(session):
    commands = [ "apt-get install -y python3-pip", "pip install flask tweepy textblob scp", "ufw allow 5000", "apt-get -y install apache2 libapache2-mod-wsgi", "systemctl enable apache2", "a2enmod wsgi"]
    for command in commands:
    	print ( "Executing " + ( command ) )
    	stdin , stdout, stderr = session.exec_command(command)
    	print (stdout.read())
    	print( " ")
    	print (stderr.read())

def uploadScripts(scripts, session):
    scp = SCPClient(session.get_transport())
    for script in scripts:
        scp.put(script, script)

    commands = ["sed -i 's/Listen 80/Listen 5000/g' /etc/apache2/ports.conf", "a2dissite 000-default.conf", "mkdir /var/www/tweetsCeg", "mv *.py /var/www/tweetsCeg","mv *.wsgi /var/www/tweetsCeg","chown -R www-data:www-data /var/www/tweetsCeg","mv 999-flask.conf /etc/apache2/sites-available"]
    for command in commands:
    	print ( "Executing " + ( command ) )
    	stdin , stdout, stderr = session.exec_command(command)
    	print (stdout.read())
    	print( " ")
    	print (stderr.read())

def closeDropletSession(session):
    session.close()

def saveVMIpAddresses(IpAddressesArray):
    filehandler = open('VMIpAddresses.obj', 'wb')
    pickle.dump(IpAddressesArray, filehandler)
def runFlask(session):
    commands = ["a2ensite 999-flask.conf"," service apache2 restart"]
    for command in commands:
    	print ( "Executing " + ( command ) )
    	stdin , stdout, stderr = session.exec_command(command)
    	print (stdout.read())
    	print( " ")
    	print (stderr.read())


if __name__ == "__main__":
    setUpDroplets()
