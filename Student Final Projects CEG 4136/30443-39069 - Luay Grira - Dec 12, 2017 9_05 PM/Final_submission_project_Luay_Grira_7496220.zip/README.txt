
Student Name: Luay Grira
Student Number: 7496220


This folder contain all the files and codes related to the industry based project.

It contains:
The final Presentation
The Midterm Presentation
The final report.

How to run the code:

In order to run the code, first need to install all the needed packages. 
Then, if you have IP addresses of your VMs, you need to modify the Ipaddresses array in the VMManager.py
If not, just un-comment the part that order VM.
Then add you twitter keys in tweetsFeatcher.py


Step to run the code:
1-Run VMmanager.py to set up your VMs
2-set flask: Here's a link how to set it up and run it: http://flask.pocoo.org/docs/0.12/quickstart/
3-Then open you browser and past this: http://127.0.0.1:5000/ in your address bar.
4-You will get a UI, you can enter the keyword and the number of tweets. Finally, click get sentiments button.