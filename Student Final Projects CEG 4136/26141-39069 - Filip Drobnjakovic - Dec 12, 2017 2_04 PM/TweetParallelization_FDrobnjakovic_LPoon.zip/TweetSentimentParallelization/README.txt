# TweetSentimentParallelization
Tests are ran using bash script for parallel code. This is in parallelProcessing folder.
There are tests for: pipe, pool, zeromq and baseline. Just uncomment which one you want to run. Twitter API Keys were removed so need to be put back in.
